# SenseIt
Studying android basics
<br><br>
Activity states log 
<br><br>
![](https://github.com/SarangKudtarkar/SenseIt/blob/master/images/activity_state.png)
